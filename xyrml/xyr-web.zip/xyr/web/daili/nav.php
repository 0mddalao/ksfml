    <nav class="navbar horizontal-menu navbar-fixed-top"><!-- set fixed position by adding class "navbar-fixed-top" -->
        
        <div class="navbar-inner">
        
            <!-- Navbar Brand -->
            <?php
            $rs=$DB->get_row("SELECT * FROM website");
            $logo=$rs['logo'];
            ?>
            <div class="navbar-brand">
                <a href="index.php" class="logo">
                    <img src="<?php echo $logo ?>" width="80" alt="" class="hidden-xs" />
                    <img src="<?php echo $logo ?>" width="30" alt="" class="visible-xs" />
                </a>
            </div>
                
            <!-- Mobile Toggles Links -->
            <div class="nav navbar-mobile">
            
                <!-- This will toggle the mobile menu and will be visible only on mobile devices -->
                <div class="mobile-menu-toggle">
                    <!-- This will open the popup with user profile settings, you can use for any purpose, just be creative -->
                    <a href="#" data-toggle="settings-pane" data-animate="true" class="hide">
                        <i class="linecons-cog"></i>
                    </a>
                    
                    <a href="#" data-toggle="user-info-menu-horizontal" class="hide">
                        <i class="fa-bell-o"></i>
                        <span class="badge badge-success">7</span>
                    </a>
                    
                    <!-- data-toggle="mobile-menu-horizontal" will show horizontal menu links only -->
                    <!-- data-toggle="mobile-menu" will show sidebar menu links only -->
                    <!-- data-toggle="mobile-menu-both" will show sidebar and horizontal menu links -->
                    <a href="#" data-toggle="mobile-menu-horizontal">
                        <i class="fa-bars"></i>
                    </a>
                </div>
                
            </div>
            
            <div class="navbar-mobile-clear"></div>        

            <!-- main menu -->      
           
    

            <ul class="navbar-nav">
                <li class="<?php echo checkIfActive('index,')?>">
                    <a href="./">
                        <i class="linecons-cloud"></i>
                        <span class="title">代理首页</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('qqlist')?>">
                    <a href="./qqlist.php">
                        <i class="linecons-desktop"></i>
                        <span class="title">用户查看</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('kmtype')?>">
                    <a href="./kmtype.php">
                        <i class="linecons-params"></i>
                        <span class="title">套餐管理</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('kmlist')?>">
                    <a href="./kmlist.php">
                        <i class="linecons-note"></i>
                        <span class="title">商品列表</span>
                    </a>
                </li>
                 <li class="<?php echo checkIfActive('wx')?>">
                    <a href="./wx.php">
                        <i class="linecons-tag"></i>
                        <span class="title">包月无限</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('linelist')?>">
                    <a href="./linelist.php">
                        <i class="fa-android"></i>
                        <span class="title">线路下载</span>
                    </a>
                </li>
<?php
/*$rs=$DB->get_row("SELECT * FROM auth_config");
$shopUrl_con=$rs['shopUrl'];*/
?>
                <!--li>
                    <a target="_blank" href="<?php echo $shopUrl_con;?>">
                        <i class="linecons-money"></i>
                        <span class="title">在线购买</span>
                    </a>
                </li-->

                <li class="<?php echo checkIfActive('weblist')?>">
                    <a href="./weblist.php">
                        <i class="linecons-shop"></i>
                        <span class="title">站点列表</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('sale')?>">
                    <a href="./sale.php">
                        <i class="linecons-paper-plane"></i>
                        <span class="title">我的推广</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('search')?>">
                    <a href="./search.php">
                        <i class="linecons-search"></i>
                        <span class="title">搜索内容</span>
                    </a>
                </li>
                <li class="<?php echo checkIfActive('dlinfo')?>">
                    <a href="./dlinfo.php">
                        <i class="linecons-pencil"></i>
                        <span class="title">信息设置</span>
                    </a>
                </li>

            </ul>

            <!-- notifications and other links -->
            <ul class="nav nav-userinfo navbar-right">
        
                <li class="dropdown user-profile">
                    <a href="#" data-toggle="dropdown">
                        <img src="../assets/images/user-1.png" alt="user-image" class="img-circle img-inline userpic-32" width="28" />
                        <span>
                            您好，<?php
$drs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user2=$drs['user'];
                             echo $user2;?>！
                            <i class="fa-angle-down"></i>
                        </span>
                    </a>
                    
                    <ul class="dropdown-menu user-profile-menu list-unstyled">
                        <li>
                            <a href="pass.php">
                                <i class="fa-wrench"></i>
                                修改密码
                            </a>
                        </li>
                        <li class="last">
                            <a href="./login.php?logout">
                                <i class="fa-lock"></i>
                                退出登录
                            </a>
                        </li>
                    </ul>
                </li>
                
            </ul>

        </div>
        
    </nav><?php 