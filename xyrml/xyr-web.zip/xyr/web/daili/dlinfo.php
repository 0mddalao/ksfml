<?php
/**
 * 我的信息
**/
$mod='blank';
include("../api.inc.php");
$title='我的信息';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");


$rs=$DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$user=$rs['user'];
$name=$rs['name'];
$pass=$rs['pass'];
$qq=$rs['qq'];
$tel=$rs['tel'];
$buy=$rs['buy'];




?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            设置信息
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
<?php
if($my=='black3'){

    $name_c=$_GET['name'];
    $pass_c=$_GET['pass'];
    $qq_c=$_GET['qq'];
    $tel_c=$_GET['tel'];
    $buy_c=$_GET['buy'];
    if(/*$mima<>$rs['pass'] && */$pass<>""){
    $sql=$DB->query("update `auth_daili` set `name`='$name_c', `pass`='$pass', `qq`='$qq_c', `tel`='$tel_c' where `id`='{$dlid}'");
    if($sql){echo '<div class="alert alert-success">
                                        <button type="button" class="close">
                                          <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                <span class="sr-only">Close</span>
                                            </button>
                                            设置成功！
                                        </div>';
                //echo "<script language='javascript'>alert('".$qq_c."');</script>";
                echo "<style>#dl_info{display: none;}</style>";
                                      }
    else{echo '<div class="alert alert-danger">
                                            设置失败！
                                        </div>';}
    }else{
     echo "<div class='alert alert-warning'>
                                            <strong>为".$user."更改密码， </strong> 新密码不能为空！</div>";
                                        
    }

}
?>

                                <form id="dl_info" action="./dlinfo.php?" method="get" class="form-horizontal validate" role="form">
                                            <input type="text" name="user" value='.$user.' hidden />
                                            <input type="text" name="my" value="black3" hidden/>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label" for="field-1">姓名</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control"id="field-1" value="<?php echo $name; ?>" name="name" data-validate="required"/>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label" for="field-2">密码</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control"id="field-2" value="<?php echo $pass; ?>" name="pass" data-validate="required"/>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label" for="field-3">QQ</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control"id="field-3" value="<?php echo $qq; ?>" name="qq" data-validate="required"/>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label" for="field-4">电话</label>
                                      <div class="col-sm-10">
                                        <input type="text" class="form-control"id="field-4" value="<?php echo $tel; ?>" name="tel" data-validate="required"/>
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label class="col-sm-2 control-label"></label>
                                      <div class="col-sm-10">
                                        <input type="submit" value="修改" class="btn btn-purple btn-single"/>
                                      </div>
                                    </div>
                                </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html> <?php 