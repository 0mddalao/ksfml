--
-- 更新默认站点名称；
--
UPDATE  `ov`.`website` SET  `title` =  '云流量' WHERE  `website`.`id` =0;
--
-- 更新默认QQ号码；
--
UPDATE  `ov`.`website` SET  `qq` =  '123123' WHERE  `website`.`id` =0;
UPDATE  `ov`.`auth_daili` SET  `qq` =  '123123' WHERE  `auth_daili`.`id` =0;
--
-- 更新默认密码；
--
UPDATE  `ov`.`auth_daili` SET  `pass` =  'xyr-dl' WHERE  `auth_daili`.`id` =0;
--
-- 更新流量卫士登录帐号密码与流控统一；
--
UPDATE  `ov`.`app_admin` SET  `username` =  '123456789' WHERE  `app_admin`.`id` =1;
UPDATE  `ov`.`app_admin` SET  `password` =  '987654321' WHERE  `app_admin`.`id` =1;