<?php
$mod='blank';
include("../api.inc.php");
$title='支付宝设置';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">支付宝即时到账交易接口设置</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">接口配置输入</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

<?php
$id ='1';
if(!$id || !$row = $DB->get_row("select * from `alipay` where id='$id' limit 1")){ exit("不存在!");}
if($_POST['type']=="update"){
echo '<div class="alert ';
$partner = daddslashes($_POST['partner']);
$alikey = daddslashes($_POST['alikey']);
$url = daddslashes($_POST['url']);
  if($DB->query("update `alipay` set `partner`='$partner',`alikey`='$alikey',`url`='$url' where id='$id'")){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#payset{display: none;}</style>";
//exit;
}
?>
      

                <form id="payset" action="./payset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                  <div class="form-group">
                    <label class="col-sm-2 control-label">合作身份者ID</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="field-1" name="partner" data-validate="required,number,min[16]" value="<?=$row['partner']?>" placeholder="以2088开头由16位纯数字组成的字符串，">
                      <p class="text-success">查看地址：https://b.alipay.com/order/pidAndKey.htm</p>
                    </div>
                  </div>  

                  <div class="form-group">
                    <label class="col-sm-2 control-label">MD5密钥</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="alikey" data-validate="required,min[16]" value="<?=$row['alikey']?>" placeholder="由数字和字母组成的32位字符串">
                        <p class="text-success">查看地址：https://b.alipay.com/order/pidAndKey.htm</p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label">网站网址</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" name="url" data-validate="required" value="<?=$row['url']?>" placeholder="需www.abc.com格式的完整路径">
                        <p class="text-success">不能加?id=123这类自定义参数，必须外网可以正常访问</p>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" type="button" class="btn btn-info btn-block">设置</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

  <!-- Bottom Scripts -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/TweenMax.min.js"></script>
  <script src="../assets/js/resizeable.js"></script>
  <script src="../assets/js/joinable.js"></script>
  <script src="../assets/js/xenon-api.js"></script>
  <script src="../assets/js/xenon-toggles.js"></script>


  <!-- Imported scripts on this page -->
  <script src="../assets/js/datepicker/bootstrap-datepicker.js"></script>

  <!-- JavaScripts initializations and stuff -->
  <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 