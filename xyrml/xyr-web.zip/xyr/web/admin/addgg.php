<?php
/**
 * 添加线路
**/
$mod='blank';
include("../api.inc.php");
$title='添加公告';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$bind_domain = explode(":",$_SERVER["HTTP_HOST"]);
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title" style="margin-bottom: 15px;">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以添加流量卫士公告</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>
           

			 <div class="alert alert-warning">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>
                    <strong>提示：</strong> 公告只会在用户登录时、连接时和切换账号时才会显示！
                  </div>
                  
          

            <div class="row">
                <div class="col-sm-12">

		
<?php
//if($tg=='1'){
if($_POST['tg']=="1"){
echo '<div class="alert '; 
$name = $_REQUEST['name']; 
$content = $_REQUEST['content'];
$time=time(); 
$DB->query("insert `app_gg`(`id`,`name`,`content`,`time`) values(null,'$name','$content','$time');"); 
$sql="insert `app_gg`(`id`,`name`,`content`,`type`,`time`) values(null,'$name','$content','$time')";
if($sql)
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>成功添加一个公告</div>
                    
                <a href="addgg.php" class="btn btn-secondary btn-icon btn-icon-standalone">                	
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="gglist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addgg{display: none;}</style>'; 
else
                echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  添加失败</div>
                <a href="addgg.php" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="gglist.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addgg{display: none;}</style>';
                }
?>


				<div id="addgg">
           	     <div class="panel panel-default">


                    <div class="panel-heading">

                      <h3 class="panel-title">请输入内容进行更新</h3>

                      <div class="panel-options">

                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                       
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>

                        <a href="#" data-toggle="remove">
                          &times;
                        </a>

                      </div>

                    </div>
                    	
            	<div class="panel-body">
                    	
             		<form id="addgg" action="./addgg.php" method="post" role="form" class="form-horizontal validate">		
              	
              		    <input type="hidden" name="my" value="config"/> 
              		  
               			<div class="form-group">
               				
                 	    	<label for="firstname" class="col-sm-1 control-label">标题</label>
                 	    	
                  	   		<div class="col-sm-10">
                        	  <input type="text" class="form-control" name="name" placeholder="请输入标题" data-validate="required">
                      		</div>
                      		
               			</div>
               			
                 	 	<div class="form-group" >
                 	 	
                     		<label for="name" class="col-sm-1 control-label">主要内容</label>
                     		
                	       	<div class="col-sm-10">
                	       		<textarea class="form-control" rows="10" name="content" placeholder="请输入公告内容" data-validate="required"></textarea>
                	       	</div>
                	       	
                 	 	</div>
    
                  		<div class="form-group">
                  			
                  	    	<div class="col-sm-offset-1 col-sm-10">
                   	        	<button type="submit" name="tg" class="btn btn-info" value="1" >提交数据</button>
                  	    	</div>
                  	    	
                 		</div>
                  
              		</form> 

             	</div>

                  </div>
                    
                   </div>
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>
    <script src="../assets/js/moment.min.js"></script>


    <!-- Imported scripts on this page -->
  <script src="../assets/js/datepicker/bootstrap-datepicker.js"></script>
  <link rel="stylesheet" href="../assets/js/multiselect/css/multi-select.css">
  <script src="../assets/js/multiselect/js/jquery.multi-select.js"></script>
    <script src="../assets/js/jquery.watermark.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 