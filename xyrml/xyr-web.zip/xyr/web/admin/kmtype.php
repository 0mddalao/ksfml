<?php
/**
 * 套餐列表
**/
$mod='blank';
include("../api.inc.php");
$title='套餐管理';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以管理维护所有套餐</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

<?php
//判断设置
$rs=$DB->get_row("SELECT * FROM auth_config");
$kmtype_con=$rs['kmtype'];
if($kmtype_con==1){
  echo "<style>#dl_list2{display: none;}</style>";
};

if($_POST['name']){
echo '';
$daili = daddslashes($_POST['daili']);
$name = daddslashes($_POST['name']);
$days = daddslashes($_POST['days']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$km_rmb = daddslashes($_POST['km_rmb']);

if(!$DB->get_row("select * from `kmtype` where `name`='$name' limit 1")){
  $sql="insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`,`dlid`) values ('{$name}','{$days}','{$maxll}','{$km_rmb}','{$daili}')";
  if($DB->query($sql))
    echo '<div class="alert alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  成功添加一个套餐</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                  <style>#addtype{display: none;}</style>';
  else
    echo '<div class="alert alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>添加失败：'.$DB->error().'</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addtype{display: none;}</style>';
}else{
  echo "<script>alert('该套餐已存在！');history.go(-1);</script>";
}
echo '';
//exit;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `kmtype` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div><style>#addtype{display: none;}</style>';
}

if(!empty($_GET['kw'])) {
  $sql=" `id`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个套餐';
}else{
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE  `i` = '0'");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个套餐';
}

?>

            <div id="addtype" class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
                    
                    <div id="dl_list">
                    <?php
                    $dl_rs=$DB->query("SELECT * FROM `auth_daili`");
                    while($dl_res = $DB->fetch($dl_rs))
                    { 
                      if($dl_res['user']=="dmg") {
                          $dl_user='超级管理员';
                      } else {
                          $dl_user=''.$dl_res['user'].'';
                      } 
                      ?>
                    <a href="kmtype.php?dlid=<?=$dl_res['id']?>" class="btn btn-info"><?=$dl_user?></a>
                    <?php }
                    ?>
                    </div>

                    <br>
                    <div id="addtype_list" class="row">
                                        <?php

                                        $dlid = $_GET['dlid'];

                                        $rs=$DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '$dlid' and  `i` = '0'");
                                        while($res = $DB->fetch($rs))
                                        { ?>

                                        <div class="col-sm-4">
                                          <div class="xe-widget xe-todo-list xe-todo-list-turquoise">
                                            <div class="xe-header">
                                              <div class="xe-icon">
                                                <i class="fa-credit-card"></i>
                                              </div>
                                              <div class="xe-label">
                                                <strong><?=$res['name']?></strong>
                                              </div>
                                                <div class="xe-nav text-right">
                                                  <a href="kmtype.php?my=del&id=<?=$res['id']?>" onclick="if(!confirm('你确实要删除此套餐吗？')){return false;}" class="xe-next" style="color: rgba(255, 255, 255, 0.50);">
                                                    <i class="fa-close"></i>
                                                  </a>
                                                </div>
                                            </div>
                                            <div class="xe-body">
                                              
                                              <ul class="list-unstyled">
                                                <li>
                                                  <label>
                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                    <span><?=$res['days']?>天使用时间</span>
                                                  </label>
                                                </li>
                                                <li>
                                                  <label>
                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                    <span><?=round(($res['maxll'])/1024/1024)?>GB流量</span>
                                                  </label>
                                                </li>
                                                <li>
                                                  <label>
                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                    <span><?=$res['km_rmb']?>元</span>
                                                  </label>
                                                </li>
                                              </ul>
                                              
                                            </div>
                                            <div class="xe-footer">
                                              <form action="kmlist.php?my=add" method="POST" class="form-inline validate">
                                                  <input type="text" class="hide" name="daili" value="<?=$res['dlid']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="kmtype_id" value="<?=$res['id']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="value" value="<?=$res['days']?>" data-validate="required,number,min[1]">
                                                  <input type="text" class="hide" name="values" value="<?=round(($res['maxll'])/1024/1024)?>" data-validate="required,number,min[1]">
                                                 <div class="form-group">
                                                    <input type="text" class="form-control" name="num" placeholder="开多少张卡？" data-validate="required,number,min[1]">
                                                  </div>
                                                 <div class="form-group">
                                                     <button type="submit" class="btn btn-white btn-single btn-block">生成</button>
                                                  </div>
                                              </form>
                                            </div>
                                          </div>
                                        </div>

                                        <?php }
                                        ?>
                    </div>
                      
                      <blockquote class="blockquote blockquote-success">
                                <form action="kmtype.php?my=add" method="POST" class="form-inline validate" style="overflow: hidden;">
                                <div class="form-group">

                                  <div class="form-group" id="dl_list2">

                                  <select class="form-control" name="daili">
                                  <?php 
                                  $dllist=$DB->query("SELECT * FROM auth_daili");
                                  while($d = $DB->fetch($dllist)): ?>
                                    <option value="<?php echo $d['id']; ?>" >用户名：<?php echo $d['user']; ?>；姓名：<?php echo $d['name']; ?></option>
                                  <?php endwhile; ?>
                                  </select>
                                      
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="name" placeholder="套餐名称" data-validate="required">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="days" placeholder="使用天数" data-validate="required,number,min[1]">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="maxll" placeholder="流量（GB）" data-validate="required,number,min[1]">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="km_rmb" placeholder="售价" data-validate="required,number,min[1]">
                                  </div>
                                  <button type="submit" class="btn btn-secondary btn-single">添加套餐</button>
                                </div>
                                </form>
                        </blockquote>
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 