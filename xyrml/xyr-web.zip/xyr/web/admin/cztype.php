<?php
/**
 * 充值列表
**/
$mod='blank';
include("../api.inc.php");
$title='充值管理';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以管理代理充值的价格类型</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

<?php
if($_POST['name']){
echo '';
$name = daddslashes($_POST['name']);
$days = daddslashes($_POST['days']);
$maxll = daddslashes($_POST['maxll'])*1024*1024;
$km_rmb = daddslashes($_POST['km_rmb']);
if(!$DB->get_row("select * from `kmtype` where `name`='$name' limit 1")){
  $sql="insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`,`i`) values ('{$name}','0','0','{$km_rmb}','1')";
  if($DB->query($sql))
    echo '<div class="alert alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  成功添加一个充值</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="cztype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                  <style>#addtype{display: none;}</style>';
  else
    echo '<div class="alert alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>添加失败：'.$DB->error().'</div>
                <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续添加</span>
                </a>
                <a href="cztype.php" class="btn btn-info btn-icon btn-icon-standalone">
                  <i class="fa-list-ol"></i>
                  <span>查看列表</span>
                </a>
                <style>#addtype{display: none;}</style>';
}else{
  echo "<script>alert('该充值已存在！');history.go(-1);</script>";
}
echo '';
//exit;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `kmtype` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div><style>#addtype{display: none;}</style>';
}

if(!empty($_GET['kw'])) {
  $sql=" `id`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个充值类型';
}else{
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE  `i` = '1'");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个充值类型';
}

?>

            <div id="addtype" class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
                    
                    <div id="addtype_list" class="row">
                                        <?php

                                        $rs=$DB->query("SELECT * FROM `kmtype` WHERE `i` = 1");
                                        while($res = $DB->fetch($rs))
                                        { ?>

                                        <div class="col-sm-4">
                                          <div class="xe-widget xe-todo-list xe-todo-list-turquoise">
                                            <div class="xe-header">
                                              <div class="xe-icon">
                                                <i class="fa-credit-card"></i>
                                              </div>
                                              <div class="xe-label">
                                                <strong><?=$res['name']?></strong>
                                              </div>
                                                <div class="xe-nav text-right">
                                                  <a href="cztype.php?my=del&id=<?=$res['id']?>" onclick="if(!confirm('你确实要删除此充值吗？')){return false;}" class="xe-next" style="color: rgba(255, 255, 255, 0.50);">
                                                    <i class="fa-close"></i>
                                                  </a>
                                                </div>
                                            </div>
                                            <div class="xe-body">
                                              
                                              <ul class="list-unstyled">
                                                <li>
                                                  <label>
                                                    <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                    <span><?=$res['km_rmb']?>元</span>
                                                  </label>
                                                </li>
                                              </ul>
                                              
                                            </div>
                                          </div>
                                        </div>

                                        <?php }
                                        ?>
                    </div>
                      
                      <blockquote class="blockquote blockquote-success">
                                <form action="cztype.php?my=add" method="POST" class="form-inline validate" style="overflow: hidden;">
                                <div class="form-group">
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="name" placeholder="充值名称" data-validate="required">
                                  </div>
                                  <div class="form-group">
                                    <input type="text" class="form-control" name="km_rmb" placeholder="充值额度" data-validate="required,number,min[1]">
                                  </div>
                                  <button type="submit" class="btn btn-secondary btn-single">添加充值</button>
                                </div>
                                </form>
                        </blockquote>
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 