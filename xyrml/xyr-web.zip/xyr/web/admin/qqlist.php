<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以管理维护所有用户帐号</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>


<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$user=$_GET['user'];
$sql=$DB->query("DELETE FROM `openvpn` WHERE iuser='$user'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}else
{
if(!empty($_GET['kw'])) {
  $sql=" `iuser`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `openvpn` WHERE{$sql}");
  $con='包含 '.$_GET['kw'].' 的共有 '.$numrows.' 个账号';
}else{
  $numrows=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个账号';
}

if($my=='qk'){//清空记录结果
echo '<div class="alert';
if($DB->query("DELETE FROM openvpn WHERE i=0")==true){
echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空成功！';
}else{
echo' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>清空失败！';
}
echo '</div>';
}


?>

            <div class="row">
                <div class="col-sm-12">
                    
                          <?php
                            if($my=='black0'){
                            $user=$_GET['user'];
                            echo '<div class="alert alert-success">
                                                <button type="button" class="close" data-dismiss="alert">
                                                  <span aria-hidden="true">×</span>
                                                  <span class="sr-only">Close</span>
                                                </button>';
                                $a = date('Y-m-d');
                                $a_time = strtotime($a);
                                $b_time = strtotime('+31 Day',$a_time);
                                $sql=$DB->query("update `openvpn` set `endtime`='$b_time',`i` ='1',`tian` ='0' where `iuser`='{$user}'");
                            if($sql){echo '设置成功，'.$user.'状态为已激活！';}
                            else{echo '设置失败！'.$DB->error().'';}
                            echo '</div>';
                            }                 
                          ?>   

                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                      <form action="qqlist.php" method="get" role="form" class="form-inline">
                      <a href="addqq.php" class="btn btn-info">添加账号</a>
                      <a href="daochu.php" class="btn btn-blue" onclick="if(!confirm('你确实要执行批量导出吗？')){return false;}">导出所有账号数据</a>
                      <a href="qqlist.php?my=qk" class="btn btn-red" onclick="if(!confirm('你确实要删除所有已禁用帐号吗？')){return false;}">清空禁用帐号</a>
                        
                        <div class="form-group pull-right">
                        <div class="form-group">
                          <input type="text" class="form-control" size="25" name="kw" placeholder="帐号">
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>

                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                            <th>服务器ID</th>
                                            <th data-priority="1">账号</th>
                                            <th data-priority="3">密码</th>
                                            <th data-priority="6">添加时间</th>
                                            <th data-priority="6">到期时间</th>
                                            <th data-priority="6">剩余流量</th>
                                            <th data-priority="6">总流量</th>
                                            <th data-priority="6">激活天数</th>
                                            <th data-priority="6">状态</th>
                                            <th data-priority="6">包月</th>
                                            <th data-priority="6">备注</th>
                                            <th data-priority="6">推荐人</th>
                                            <th data-priority="6">充值送推荐人流量？</th>
                                            <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <?php
                                        $pagesize=30;
                                        $pages=intval($numrows/$pagesize);
                                        if ($numrows%$pagesize)
                                        {
                                         $pages++;
                                         }
                                        if (isset($_GET['page'])){
                                        $page=intval($_GET['page']);
                                        }
                                        else{
                                        $page=1;
                                        }
                                        $offset=$pagesize*($page - 1);
                                        //$zt = array('0'=>'<font color=green>正常</font>','1'=>'<font color=red>密码错误</font>','2'=>'<font color=red>冻结</font>','3'=>'<font color=red>开启设备锁</font>');
                                        $rs=$DB->query("SELECT * FROM `openvpn` WHERE{$sql} order by id desc limit $offset,$pagesize");
                                        while($res = $DB->fetch($rs))
                                        {
                                          if($res['endtime']==0) {
                                              $ok='<a class="btn btn-xs btn-secondary" href="./qqlist.php?my=black0&user='.$res['iuser'].'" onclick="return confirm(\'你确实要进行操作吗？\');">激活</a>&nbsp;';
                                          } else {
                                              $ok='';
                                          } 
                                          ?>
                                        <tr>
                                        <th><span class="co-name"><?=$res['fwqid']?></span></th>
                                        <td><?=$res['iuser']?></td>
                                        <td><?=$res['pass']?></td>
                                        <td><?=date("Y-m-d",$res['starttime'])?></td>
                                        <td><?=date("Y-m-d",$res['endtime'])?></td>
                                        <td><?=round(($res['maxll']-$res['isent']-$res['irecv'])/1024/1024)?>MB</td>
                                        <td><?=round(($res['maxll'])/1024/1024)?>MB</td>
                                        <td><?=$res['tian']?></td>
                                        <td><?=($res['i']?'<span class="badge badge-secondary">开通</span>':'<span class="badge badge-default">禁用</span>')?></td>
                                        <td><?=($res['by']?'<span class="badge badge-info">是</span>':'<span class="badge badge-default">否</span>')?></td>
                                        <td><?=$res['notes']?></td>
                                        <td><?=$res['tj_user']?></td>
                                        <td><?=($res['tj_ok']?'<div class="label label-info">有</div>':'<div class="label label-white">无</div>')?></td>
                                        <td><?=$ok?><a class="btn btn-xs btn-turquoise" href="./qset.php?user=<?=$res['iuser']?>">配置</a>&nbsp;<a href="./qqlist.php?my=del&user=<?=$res['iuser']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此账号吗？')){return false;}">删除</a></td>
                                        </tr>

                                        <?php }
                                        ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      
                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="qqlist.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="qqlist.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="qqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="qqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="qqlist.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="qqlist.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页
                      }
                      ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>


    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<script type="text/javascript">
    /*function del(){
      var str="";
      $("input[name='ids']").each(function(){ 
          if($(this).prop('checked')){
            str += $(this).val()+","
          }
      })
      $.post('delall.php?action=delall',{ids:str},function(data){
        alert(data);
        window.location.reload();
      });
      
    }
   function checkAll(obj){
      $("input[type='checkbox']").prop('checked', $(obj).prop('checked'));
  }*/
</script><?php 