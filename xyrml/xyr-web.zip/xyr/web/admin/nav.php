<?php
$url = $_SERVER['PHP_SELF'];
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$count=$DB->count("SELECT count(*) from `openvpn` WHERE 1");
$count2=$DB->count("SELECT count(*) from `openvpn` WHERE i=1");
$countdaili=$DB->count("SELECT count(*) from `auth_daili` WHERE 1");
$countdaili2=$DB->count("SELECT count(*) from `auth_daili` WHERE active=0");
$countkm=$DB->count("SELECT count(*) from `auth_kms` WHERE 1");
$countkm2=$DB->count("SELECT count(*) from `auth_kms` WHERE isuse=0");
?>
        <div class="sidebar-menu toggle-others fixed">
            
            <div class="sidebar-menu-inner">    
                
                <header class="logo-env">
                    
                    <!-- logo -->
                    <div class="logo">
                        <a href="index.php" class="logo-expanded">
                            <img src="../assets/images/logo@2x.png" width="120" alt="" />
                        </a>
                        
                        <a href="index.php" class="logo-collapsed">
                            <img src="../assets/images/logo-collapsed@2x.png" width="40" alt="" />
                        </a>
                    </div>
                    
                    <!-- This will toggle the mobile menu and will be visible only on mobile devices -->
                    <div class="mobile-menu-toggle visible-xs">
                        <a href="#" data-toggle="user-info-menu">
                            <i class="fa-bell-o"></i>
                        </a>
                        
                        <a href="#" data-toggle="mobile-menu">
                            <i class="fa-bars"></i>
                        </a>
                    </div>
                    
                    <!-- This will open the popup with user profile settings, you can use for any purpose, just be creative -->
                    <div class="settings-icon">
                        <a href="#" data-toggle="settings-pane" data-animate="true">
                            <i class="linecons-cog"></i>
                        </a>
                    </div>
                    
                                
                </header>
                                    
                <ul id="main-menu" class="main-menu">
                    <!-- add class "multiple-expanded" to allow multiple submenus to open -->
                    <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
                    <li class="<?php echo checkIfActive('index,')?>">
                        <a href="index.php">
                            <i class="fa-dashboard"></i>
                            <span class="title">平台首页</span>
                        </a>
                    </li>
                    <li class="<?php echo checkIfActive('fwqlist,addfwq,hosts,')?>">
                        <a href="#">
                            <i class="linecons-globe"></i>
                            <span class="title">服务管理</span>
                        </a>
                        <ul>
                            <li class="<?php echo checkIfActive('addfwq,')?>">
                                <a href="addfwq.php">
                                    <span class="title">添加服务器</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('fwqlist,')?>">
                                <a href="fwqlist.php">
                                    <span class="title">服务器列表</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('hosts,')?>">
                                <a href="hosts.php">
                                    <span class="title">DNS拦截</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="<?php echo checkIfActive('pladd,addqq,qqlist,daochu,')?>">
                        <a href="#">
                            <i class="linecons-desktop"></i>
                            <span class="title">账号管理</span>
                        </a>
                        <ul>
                            <li class="<?php echo checkIfActive('pladd,')?>">
                                <a href="pladd.php">
                                    <span class="title">批量添加账号</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('addqq,')?>">
                                <a href="addqq.php">
                                    <span class="title">添加账号</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('qqlist,')?>">
                                <a href="qqlist.php">
                                    <span class="title">账号列表</span>
                                    <span class="label label-success pull-right"><?php echo $count?></span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="<?php echo checkIfActive('kmtype,kmlist,search,')?>">
                        <a href="#">
                            <i class="linecons-note"></i>
                            <span class="title">商品管理</span>
                        </a>
                        <ul>
                            <li class="<?php echo checkIfActive('kmtype,')?>">
                                <a href="kmtype.php">
                                    <span class="title">套餐管理</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('kmlist,')?>">
                                <a href="kmlist.php">
                                    <span class="title">商品列表</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('search,')?>">
                                <a href="search.php">
                                    <span class="title">内容搜索</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="<?php echo checkIfActive('daili,dlconfig,dlkm,cztype,')?>">
                        <a href="#">
                            <i class="linecons-star"></i>
                            <span class="title">代理管理</span>
                        </a>
                        <ul>
                            <li class="<?php echo checkIfActive('daili,')?>">
                                <a href="daili.php">
                                    <span class="title">代理用户列表</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('dlkm,')?>">
                                <a href="dlkm.php">
                                    <span class="title">代理充值卡密</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('dlconfig,')?>">
                                <a href="dlconfig.php">
                                    <span class="title">代理高级设置</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('cztype,')?>">
                                <a href="cztype.php">
                                    <span class="title">代理充值管理</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                    <li class="<?php echo checkIfActive('weblist,banner,payset,website,passwd,')?>">
                        <a href="#">
                            <i class="linecons-shop"></i>
                            <span class="title">官网管理</span>
                        </a>
                        <ul>
                            <li class="<?php echo checkIfActive('weblist,')?>">
                                <a href="weblist.php">
                                    <span class="title">站点列表</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('banner,')?>">
                                <a href="banner.php">
                                    <span class="title">大图设置</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('payset,')?>">
                                <a href="payset.php">
                                    <span class="title">支付宝设置</span>
                                </a>
                            </li>                            <li class="<?php echo checkIfActive('passwd,')?>">                                <a href="passwd.php">                                    <span class="title">修改后台密码</span>                                </a>                            </li>
                        </ul>
                    </li>
                    <li class="<?php echo checkIfActive('open,openlist,hosts,newopen,')?>">
                        <a href="#">
                            <i class="fa-android"></i>
                            <span class="title">线路管理</span>
                        </a>
                        <ul>
<?php
if(is_file("../../../install.lock")){
}
else
{
?>
                            <li class="<?php echo checkIfActive('newopen,')?>">
                                <a href="newopen.php">
                                    <span class="title">激活线路</span>
                                    <span class="label label-purple pull-right hidden-collapsed">Now</span>
                                </a>
                            </li>
<?php
}
?>
                            <li class="<?php echo checkIfActive('open,')?>">
                                <a href="open.php">
                                    <span class="title">添加线路</span>
                                </a>
                            </li>
                            
                            <li class="<?php echo checkIfActive('openlist,')?>">
                                <a href="openlist.php">
                                    <span class="title">线路列表</span>
                                </a>
                            </li>
                            

                        </ul>
                    </li>
                    
                <li class="<?php echo checkIfActive('addgg,gglist,')?>">
                        <a href="#">
                            <i class="linecons-cloud"></i>
                            <span class="title">公告管理</span>
                        </a>
                        <ul>
                        	
                        	<li class="<?php echo checkIfActive('addgg,')?>">
                                <a href="addgg.php">
                                    <span class="title">添加公告</span>
                                </a>
                            </li>
                            
                            <li class="<?php echo checkIfActive('gglist,')?>">
                                <a href="gglist.php">
                                    <span class="title">公告列表</span>
                                </a>
                            </li>
                        </ul>
                    </li>

                    <li class="<?php echo checkIfActive('log,online,script,')?>">
                        <a href="#">
                            <i class="linecons-globe"></i>
                            <span class="title">平台日志</span>
                        </a>
                        <ul>
                            <li class="<?php echo checkIfActive('log,')?>">
                                <a href="log.php">
                                    <span class="title">操作记录</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('online,')?>">
                                <a href="online.php">
                                    <span class="title">在线用户</span>
                                </a>
                            </li>
                            <li class="<?php echo checkIfActive('script,')?>">
                                <a href="script.php">
                                    <span class="title">实时监控日志</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                        
            </div>
            
        </div><?php 