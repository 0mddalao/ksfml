<?php
$mod='blank';
include("../api.inc.php");
$title='配置线路';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处按需要配置线路</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>
<?php
$id = daddslashes($_GET['id']);
?>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">进行线路编号为 <?=$id?> 的配置</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

<?php
if(!$id || !$row = $DB->get_row("select * from `line` where id='$id' limit 1")){ exit("线路不存在!");}
if($_POST['xg']=="1"){
echo '<div class="alert ';
//$category_id = daddslashes($_POST['category_id']);
$name = daddslashes($_POST['name']);
$content = daddslashes($_POST['content']);
$linetype = daddslashes($_POST['linetype']);
$type = daddslashes($_POST['type']);
$label = daddslashes($_POST['label']);
$show = daddslashes($_POST['show']);
$DB->query("update `line` set `name`='$name',`content`='$content',`type`='$type',`group`='$linetype',`show`='$show',`label`='$label' where id='$id'");
$sql="update `line` set `name`='$name',`content`='$content',`type`='$type',`group`='$linetype',`show`='$show',`label`='$label' where id='$id'";
  //if($DB->query("update `line` set `name`='$name',`content`='$content',`type`='$type',`group`='$linetype',`show`='$show',`label`='$label' where id='$id'"));
  if($DB->query($sql)){
    echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改成功！';
  }else{
    echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  修改失败！'.$DB->error();
  }
echo '</div>';
echo "<style>#lineset{display: none;}</style>";
//exit;
}
?>
      

                <form id="lineset" action="./lineset.php?id=<?=$id?>" method="post" role="form" class="form-horizontal">
                <input type="hidden" name="type" value="update" />

                    <div class="form-group">
                      <label class="col-sm-2 control-label">线路名称：</label>
                      <div class="col-sm-9">
                        <input type="text" class="form-control" id="field-1" placeholder="输入模式名称" name="name" data-validate="required" value="<?=$row['name']?>">
                      </div>
                    </div>

							<div class="form-group">
                              <label class="col-sm-2 control-label">线路类型：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="field-1" placeholder="线路类型输入" name="type" data-validate="required" value="<?=$row['type']?>">
                              </div>
                            </div>
                            
							<div class="form-group">
                              <label class="col-sm-2 control-label">显示标签：</label>
                              <div class="col-sm-9">
                                <input type="text" class="form-control" id="field-1" placeholder="显示标签输入" name="label" data-validate="required" value="<?=$row['label']?>">
                              </div>
                            </div>
                            

                  <div class="form-group">
                    <label class="col-sm-2 control-label">线路种类：</label>
                    <div class="col-sm-9">
                      <label class="radio-inline">
                        <input type="radio" name="linetype" <?php if(1 == $row['group'])echo "checked=\"\"";?> value="1">
                        移动
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="linetype" <?php if(2 == $row['group'])echo "checked=\"\"";?> value="2">
                        联通
                      </label>
                      <label class="radio-inline">
                        <input type="radio" name="linetype" <?php if(3 == $row['group'])echo "checked=\"\"";?> value="3">
                        电信
                      </label>

                      <label class="radio-inline">

                        <input type="radio" name="linetype" <?php if(4 == $row['group'])echo "checked=\"\"";?> value="4">

                        其它

                      </label>
                    </div>
                  </div>

                    <div class="form-group">
                      <label class="col-sm-2 control-label">模式内容：</label>
                      <div class="col-sm-9">
                         <textarea class="form-control" cols="5" id="field-5" name="content" rows="25" data-validate="required"><?=$row['content']?></textarea>
                      </div>
                    </div>   


                            <div class="form-group">
                                <div class="col-sm-offset-2 col-sm-10">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" checked="" name="show" value="1">是否启用
                                        </label>
                                    </div>
                                </div>
                            </div>

                  <div class="form-group">
                    <label class="col-sm-2 control-label"></label>
                    <div class="col-sm-9">
                      <button type="submit" name="xg" class="btn btn-info btn-block" value="1">修改</button>
                    </div>
                  </div>
                  
                </form>

                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

  <!-- Bottom Scripts -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/TweenMax.min.js"></script>
  <script src="../assets/js/resizeable.js"></script>
  <script src="../assets/js/joinable.js"></script>
  <script src="../assets/js/xenon-api.js"></script>
  <script src="../assets/js/xenon-toggles.js"></script>


  <!-- Imported scripts on this page -->
  <script src="../assets/js/datepicker/bootstrap-datepicker.js"></script>

  <!-- JavaScripts initializations and stuff -->
  <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 